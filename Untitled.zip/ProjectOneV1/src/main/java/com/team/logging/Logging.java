package com.team.logging;

import org.apache.log4j.Logger;

public class Logging
{
	public final static Logger log = Logger.getLogger(Logging.class);
}