package com.team.core;

public class Manager extends User
{
	public Manager(String username, String password)
	{
		super(username, password, "manager");
	}
}