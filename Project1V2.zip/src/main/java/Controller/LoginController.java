package Controller;

import javax.servlet.http.HttpServletRequest;

import DAO.UserDaoImpl;
import Models.User;

public class LoginController {

	public static String Login(HttpServletRequest request) {

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");

		UserDaoImpl userDaoImpl = new UserDaoImpl();

		User user = new User();
		user = userDaoImpl.confirmLogin(userName, password);
		// user = userDaoImpl.getUserByUsername(userName);

		request.getSession().setAttribute("User", user);

		if (userName.equals(user.getUserName()) && password.equals(user.getPassword())) {

			if (user.getRole().equals("MAN")) {

				return "/html/Man.html";

			} else if (user.getRole().equals("EMP")) {

				return "/html/Emp.html";

			} else {
				

				return "/html/Login.html";
			}
		}
		return "/html/Login.html";
	}

}


// return "/html/Emp.html";
//
//
// return "/html/Login.html";
