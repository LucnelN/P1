package Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RequestHelper {
	
public static String process(HttpServletRequest request, HttpServletResponse response) {
		String uri = request.getRequestURI();
		switch(request.getRequestURI()) {
		//depending on the URI that comes with the request, this 
		//method chooses the corresponding controller and calls
		//the method within that controller
		
		case "/Project1/html/Login.do":
			return LoginController.Login(request);
		
		case "/Project1/html/Home.do":
			return HomeController.Home(request, response);
			
		case "/Project1/html/Create.do":
			return CreateController.Create(request);
			
		//case "/PetsFrontController/html/Update.do":
			//return ProfileController.Update(request);
			
		default:
			return "/html/Login.html";
		}
	}
}


