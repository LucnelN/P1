package Controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Models.User;



public class HomeController {
	
	public static String Home(HttpServletRequest request, HttpServletResponse response) {
		//retrieving the pet object in our session
		User user = (User) request.getSession().getAttribute("User");

		try {
			//converting the object pet into JSON for JavaScript to receive
			response.getWriter().write(new ObjectMapper().writeValueAsString(user));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		/*
		 * Marshalling (similar to serialization) is the process of transforming memory
		 * representation of an object to a data format suitable for storage or
		 * transmission.
		 * 
		 * Object -> JSON Unmarshalling JSON -> Object
		 * 
		 * Our tool of choice: Jackson (JSON marshalling tool)
		 */
		return null;
	}


}
