package Controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import DAO.TicketDAOImpl;
import Models.Ticket;
import Models.User;

public class CreateController {
	
	public static String Create(HttpServletRequest request) {
		
		User u = (User)request.getSession().getAttribute("User");
				
		String userName = u.getUserName();
		String type = request.getParameter("type");
		double amount = Double.parseDouble(request.getParameter("amount"));
		String description = request.getParameter("description");
		int status = 1;
		
		TicketDAOImpl ticketDao = new TicketDAOImpl();
		
		Ticket tickets = new Ticket();
		
		
		tickets.setAmount(amount);
		tickets.setDescription(description);
		tickets.setEmployee_username(userName);
		tickets.setStatus(1);
		tickets.setTicket_ID(1);
		tickets.setType(type);
		
		
		ticketDao.insertTicket(tickets);
		
		
		
		return "/html/Emp.html";
		
	}

}

