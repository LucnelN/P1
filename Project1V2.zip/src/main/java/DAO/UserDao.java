package DAO;

import java.sql.SQLException;
import java.util.List;

import Models.User;


public interface UserDao {
	public User confirmLogin(String userName, String password);
	public User getUserByUsername(String userName);
	public List<User> getUserByRole(String Role);
	public List<User> getAllUser();

}
