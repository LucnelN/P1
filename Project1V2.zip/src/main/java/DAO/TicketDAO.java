package DAO;

import java.util.ArrayList;

import Models.Ticket;



public interface TicketDAO
{
	public void insertTicket(Ticket ticket);
	
	public Ticket getTicketById(int id);
	
	public ArrayList<Ticket> getTicketsByType(String type);
	
	public ArrayList<Ticket> getAllTickets();
	
	public void updateTicket(Ticket ticket);
	
	public void deleteTicket(Ticket ticket);
}
