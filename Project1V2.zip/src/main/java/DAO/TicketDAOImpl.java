package DAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Models.Ticket;


public class TicketDAOImpl implements TicketDAO
{
	private static String url = "jdbc:oracle:thin:@lukedb.cjhjtyllvpw0.us-east-2.rds.amazonaws.com:1521:ORCL";
	private static String username = "Lucnel954";
	private static String password = "Pompano954";
	
	private static Connection conn;
	
	public TicketDAOImpl() {
		try {
			conn = DriverManager.getConnection(url,username,password);
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void insertTicket(Ticket ticket) {
		try {
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Tickets (username, amount, ticket_Desc,"
																			+ "type, status, ticket_ID) VALUES (?,?,?,?,?,?)");
			
			ps.setString(1, ticket.getEmployee_username());
			ps.setDouble(2, ticket.getAmount());
			ps.setString(3, ticket.getDescription());
			ps.setString(4, ticket.getType());
			ps.setInt(5, ticket.getStatus());
			ps.setInt(6, ticket.getTicket_ID());
			
			ps.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Ticket getTicketById(int id) {
		Ticket ticket = null;
		
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM Tickets WHERE ticketID = ?");
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
				ticket = new Ticket(id, rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getString(5), rs.getInt(6));
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		return ticket;
	}

	@Override
	public ArrayList<Ticket> getTicketsByType(String type) {
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket = null;
		
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM Tickets WHERE type = ?");
			ps.setString(1, type);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				ticket = new Ticket(rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getString(5), rs.getInt(6));
				
				tickets.add(ticket);
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return tickets;
	}

	@Override
	public ArrayList<Ticket> getAllTickets() {
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket = null;
		
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM Tickets");
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				ticket = new Ticket(rs.getInt(1), rs.getString(2), rs.getDouble(3), rs.getString(4), rs.getString(5), rs.getInt(6));
				
				tickets.add(ticket);
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return tickets;
	}

	@Override
	public void updateTicket(Ticket ticket) {
		try {
			CallableStatement cs = conn.prepareCall("{call update_ticket(?,?,?,?,?,?)}");
			
			cs.setInt(1, ticket.getTicket_ID());
			cs.setString(2, ticket.getEmployee_username());
			cs.setDouble(3, ticket.getAmount());
			cs.setString(4, ticket.getDescription());
			cs.setString(5, ticket.getType());
			cs.setInt(6, ticket.getStatus());
			
			cs.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void deleteTicket(Ticket ticket) {
		try {
			PreparedStatement ps = conn.prepareStatement("DELETE FROM Tickets WHERE ticketId = ?");
			
			ps.setInt(1,ticket.getTicket_ID());
			
			ps.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}


}