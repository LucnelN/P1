package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Models.User;



public class UserDaoImpl implements UserDao {

	private static String url = "jdbc:oracle:thin:@lukedb.cjhjtyllvpw0.us-east-2.rds.amazonaws.com:1521:ORCL";
	private static String username = "Lucnel954";
	private static String password1 = "Pompano954";
	
	static{

	       try {

	           Class.forName("oracle.jdbc.driver.OracleDriver");

	       } catch (ClassNotFoundException e) {

	           e.printStackTrace();

	       }

	   }

	
	@Override
	public User confirmLogin(String userName, String password) {
		
		User user = null;
		
		try(Connection conn = DriverManager.getConnection(url, username, password1)){
			
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS WHERE UserName=? and Password=?");

			ps.setString(1, userName);
			ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();

			while(rs.next()) {
				user = new User(userName, password, rs.getString("Role"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return user;
	}
		
	@Override
	public User getUserByUsername(String userName) {
		User user = new User();
		
			try(Connection conn = DriverManager.getConnection(url, username, password1)){
				
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS WHERE USERNAME = ?");
				
				ps.setString(1, username);
				ResultSet rs = ps.executeQuery();
			
				while(rs.next()) {
					user = new User(rs.getString(1), rs.getString(2), rs.getString(3));
					
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return user;
	}
	@Override
	public List<User> getUserByRole(String Role) {
		List<User> getUsersByRole = new ArrayList<>();
		
		try(Connection conn = DriverManager.getConnection(url, username, password1)){
	
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS WHERE ROLE = ?");
	
			ps.setString(1, Role);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				getUsersByRole.add(new User(rs.getString(1), rs.getString(2),rs.getString(3)));
		
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return getUsersByRole;
			}

	
	@Override
	public List<User> getAllUser() {
		List<User> getAllUser = new ArrayList<>();
		
		try(Connection conn = DriverManager.getConnection(url, username, password1)){
			
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				getAllUser.add(new User(rs.getString(1), rs.getString(2),rs.getString(3)));
				

				//getAllUsers.add(user);
			}

		} catch (SQLException e) {

		} 

		return getAllUser;
	}
}
	
	
	
	
	
//	@Override
//	public User getUserByUsername(String userName) {
//			User user = new User();
//		
//			try(Connection conn = DriverManager.getConnection(url, username, password)){
//				
//				PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS WHERE USERNAME = ?");
//				
//				ps.setString(1, userName);
//				ResultSet rs = ps.executeQuery();
//			
//				while(rs.next()) {
//					user = new User(rs.getString(1), rs.getString(2), rs.getString(3));
//					
//					}
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//				return user;
//	}
//				
//			
//	@Override
//	public List<User> getUserByRole(String Role) {
//		List<User> getUsersByRole = new ArrayList<>();
//				
//		try(Connection conn = DriverManager.getConnection(url, username, password)){
//			
//			PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS WHERE ROLE = ?");
//			
//			ps.setString(1, Role);
//			ResultSet rs = ps.executeQuery();
//			while(rs.next()) {
//				getUsersByRole.add(new User(rs.getString(1), rs.getString(2),rs.getString(3)));
//				
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//			return getUsersByRole;
//			}
//		
//		
//
//	public List<User> getAllUser() {
//		List<User> getAllUsers = new ArrayList<>();
//		
//		try(Connection conn = DriverManager.getConnection(url, username, password)){
//			
//			PreparedStatement ps = conn.prepareStatement("SELECT * FROM USERS");
//			ResultSet rs = ps.executeQuery();
//			while(rs.next()) {
//				getAllUsers.add(new User(rs.getString(1), rs.getString(2),rs.getString(3)));
//				
//
//				//getAllUsers.add(user);
//			}
//
//		} catch (SQLException e) {
//
//		} 
//
//		return getAllUsers;
//	}
//
//
//	@Override
//	public User getUserByUsername(String userName) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	
//	
//	
//}
	
	
