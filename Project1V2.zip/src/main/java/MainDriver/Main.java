package MainDriver;

import DAO.TicketDAOImpl;
import DAO.UserDaoImpl;
import Models.Ticket;

public class Main {

	public static void main(String[] args) {

		UserDaoImpl UserDaoImpl = new UserDaoImpl();
		//UsersDaoImpl.getUsersByRole("EMP");
		//System.out.println(UsersDaoImpl.getUserByRole("MAN"));
		//System.out.println(UsersDaoImpl.getUsersByUsername("luke"));
		//for(Users u : UsersDaoImpl.getAllUsers()) {
			//System.out.println(u);
		//}
		
		System.out.println(UserDaoImpl.confirmLogin("luke","hulk"));
		
//		TicketDAOImpl ticketDAOImpl = new TicketDAOImpl();
//		Ticket tickets = new Ticket();
//		tickets.setAmount(500);
//		tickets.setDescription("miami");
//		tickets.setEmployee_username("luke");
//		tickets.setStatus(1);
//		tickets.setTicket_ID(1);
//		tickets.setType("Travel");
//		tickets.setTicket_ID(1);
//		
//		
//		
//		ticketDAOImpl.insertTicket(tickets);
//		System.out.println(tickets);
//		
	}
	}


